package com.desafio.forohub.domain.usuario;

public enum Role {
    ADMINISTRADOR,
    USUARIO,
    EXPECTADOR
}

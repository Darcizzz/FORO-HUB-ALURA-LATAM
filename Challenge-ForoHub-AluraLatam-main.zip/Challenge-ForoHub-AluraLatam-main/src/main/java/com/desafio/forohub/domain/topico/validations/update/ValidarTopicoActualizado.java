package com.desafio.forohub.domain.topico.validations.update;

import com.desafio.forohub.domain.topico.dto.ActualizarTopicoDTO;

public interface ValidarTopicoActualizado {
    void validate(ActualizarTopicoDTO data);
}

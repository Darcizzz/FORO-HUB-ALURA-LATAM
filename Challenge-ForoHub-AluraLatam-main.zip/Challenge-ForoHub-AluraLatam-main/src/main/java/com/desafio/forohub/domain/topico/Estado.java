package com.desafio.forohub.domain.topico;

public enum Estado {
    OPEN,
    CLOSED,
    DELETED
}
